<?php

use App\Http\Middleware\JWT;
use Illuminate\Support\Facades\Route;
use Leo\Products\Controllers\ProductsController;

Route::resource('products', ProductsController::class);
Route::put('/products/switch/{id}',[ProductsController::class,'switchProduct']);
Route::delete('/products/drop-image/{id}/{imageName}', [ProductsController::class, 'removeImage']);
Route::post('/products/set-image/{id}/{imageName}', [ProductsController::class, 'setImage']);
Route::put('/products/{id}',[ProductsController::class,'update']);
Route::post('/products/set-image/{id}/{imageName}', [ProductsController::class, 'setImage']);

Route::prefix('api/')->name('api.')->group(function () {
    Route::prefix('products')->name('products.')->group(function () {
        Route::get('/',[ProductsController::class,'api_product']);
        Route::get('/{id}',[ProductsController::class,'api_single_product']);
    });
});